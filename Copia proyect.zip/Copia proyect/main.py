from keras.models import load_model  # TensorFlow is required for Keras to work
from PIL import Image, ImageOps  # Install pillow instead of PIL
from discord.ext import commands
from io import BytesIO
import numpy as np
import discord
import pyttsx3
import requests
import asyncio

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)


@bot.command()
async def start(ctx):
    await ctx.send('Hola, bienvenido')

engine = pyttsx3.init()


@bot.command()
async def sound(ctx, rate: int = 75):
    engine.setProperty("rate", rate)

    current_rate = engine.getProperty("rate")

    await ctx.send(f"Velocidad de habla configurada a {current_rate}.")


def getWeather(city: str) -> str:
    base_url = f"https://wttr.in/{city}?format=%c+%t"
    response = requests.get(base_url)

    if response.status_code == 200:
        return response.text.strip()
    else:
        return "No se pudo obtener la información del clima, por favor intente más tarde."


def speak(text: str):
    engine.say(text)
    engine.runAndWait()


def get_fact():
    url = "https://uselessfacts.jsph.pl/api/v2/facts/random"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        return data.get("text", "No sé encontró el texto")
    else:
        return "No se pudo obtener la información, por favor intente más tarde."


@bot.command()
async def facts(ctx):
    fact = get_fact()
    await ctx.send(fact)
    speak(fact)


@bot.command()
async def weather(ctx, city: str, rate: int = 125):
    engine.setProperty("rate", rate)
    weather_info = getWeather(city)
    await ctx.send(f'Clima en {city}: {weather_info}')
    speak(f"El clima en {city} es {weather_info}")

model = load_model("keras_Model.h5", compile=False)

# Cargar las etiquetas
with open("labels.txt", "r", encoding="utf-8") as file:
    class_names = file.readlines()


def identificar_residuo(image_bytes):

    # Abrir la imagen recibida
    image = Image.open(BytesIO(image_bytes)).convert("RGB")

    # Preparar la imagen para el modelo
    size = (224, 224)
    image = ImageOps.fit(
        image,
        size,
        Image.Resampling.LANCZOS
    )

    # Convertir a array
    image_array = np.asarray(image)

    # Normalizar
    normalized_image = (
        image_array.astype(np.float32) / 127.5
    ) - 1

    # Preparar los datos
    data = np.ndarray(
        shape=(1, 224, 224, 3),
        dtype=np.float32
    )

    data[0] = normalized_image

    # Realizar predicción
    prediction = model.predict(data, verbose=0)

    index = np.argmax(prediction)
    confidence = float(prediction[0][index])

    # Obtener nombre de la clase
    class_name = class_names[index].strip()

    # Eliminar el número inicial de la etiqueta
    parts = class_name.split(maxsplit=1)

    if len(parts) == 2 and parts[0].isdigit():
        class_name = parts[1]

    return class_name, confidence


url_r = "https://www.unep.org/es/publications/report/perspectiva-mundial-de-la-gestion-de-residuos-2024"
recomendaciones = {

    "plastic": {
        "categoria": "Residuo reciclable",
        "contenedor": "Contenedor para plásticos",
        "instrucciones": "Enjuaga el envase, retira los restos de producto y aplástalo si es posible."
    },

    "vidrio": {
        "categoria": "Residuo reciclable",
        "contenedor": "Contenedor para vidrio",
        "instrucciones": "Deposita el vidrio limpio y evita mezclarlo con cerámica o espejos."
    },

    "paper": {
        "categoria": "Residuo reciclable",
        "contenedor": "Contenedor para papel y cartón",
        "instrucciones": "Mantén el papel seco y libre de grasa o restos de comida."
    },

    "metal": {
            "categoria": "Residuo metálico",
            "contenedor": "Contenedor para metales",
            "instrucciones": "Mantén los metales limpios y libres de residuos que puedan contaminarlos."
        },

    "cardboard": {
        "categoria": "Residuo reciclable",
        "contenedor": "Contenedor para papel y cartón",
        "instrucciones": "Desarma las cajas y mantenlas limpias y secas."
    },

    "trash": {
        "categoria": "Residuo especial",
        "contenedor": "Depende del residuo, son difíciles de manejar, pueden ser corrrosivos, tóxicos, inflamables, etc",
        "instrucciones": f"Tienen tratos especiales según el residuo especial que sea. Consulta {url_r} para más información."
    }
}

@bot.command()
async def clasificar(ctx):

    # Comprobar si el usuario adjuntó una imagen
    if not ctx.message.attachments:
        await ctx.send(
            "Por favor, adjunta una fotografía del residuo."
        )
        return

    attachment = ctx.message.attachments[0]

    # Comprobar que sea una imagen
    if not attachment.content_type or not attachment.content_type.startswith("image/"):
        await ctx.send(
            "El archivo enviado no es una imagen válida."
        )
        return

    await ctx.send("Analizando archivo...")

    try:
        # Descargar la imagen desde Discord
        image_bytes = await attachment.read()

        # Ejecutar el modelo sin bloquear el bot
        class_name, confidence = await asyncio.to_thread(
            identificar_residuo,
            image_bytes
        )

        # Comprobar la confianza
        if confidence < 0.60:
            await ctx.send(
                "El modelo no está suficientemente seguro de qué residuo es. "
                "Intenta enviar otra fotografía con mejor iluminación."
            )
            return

        # Mostrar el resultado
        informacion = recomendaciones.get(class_name)

        if informacion:

            respuesta = (
                f"**¡Residuo identificado!**\n\n"
                f"**Tipo:** {class_name}\n"
                f"**Confianza:** {confidence:.2%}\n"
                f"**Categoría:** {informacion['categoria']}\n"
                f"**Contenedor:** {informacion['contenedor']}\n"
                f"**Recomendación:** {informacion['instrucciones']}"
            )

        else:

            respuesta = (
                f"**Residuo identificado:** {class_name}\n"
                f"**Confianza:** {confidence:.2%}\n\n"
                "Todavía no hay recomendaciones para esta categoría."
            )

        await ctx.send(respuesta)

    except Exception as e:
        print(f"Error al clasificar: {e}")

        await ctx.send(
            "Ocurrió un error al analizar la imagen. "
            "Inténtalo nuevamente."
        )
bot.run("MTU2ODAwOTY5MjMyNjY2MjIyNA.GrtcBA.hanXrR2krYWWxEAkhK0dpwdisZMiR_6uDHFGE8")
